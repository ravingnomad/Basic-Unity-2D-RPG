﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NpcTalk : MonoBehaviour {
    public Dialogue dialogue;
    public bool in_dialogue = false;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            Debug.Log("Entered NPC range");
        }
    }
    private void Update()
    {
        Animator animator = FindObjectOfType<DialogueManager>().animator;
        if (animator.GetBool("IsOpen") == false)
        {
            in_dialogue = false;
        }
        if (Input.inputString == "e" && animator.GetBool("IsOpen") == false)
        {
            Debug.Log("Enter dialogue");
            if (in_dialogue == false)
            {
                FindObjectOfType<DialogueManager>().StartDialogue(dialogue);
                in_dialogue = true;
            }
        }
        else if (Input.inputString == "e" && animator.GetBool("IsOpen") == true)
        {
            FindObjectOfType<DialogueManager>().DisplayNextSentence();
        }
        else if (Input.inputString == "q" && animator.GetBool("IsOpen") == true)
        {
            FindObjectOfType<DialogueManager>().EndDialogue();
            in_dialogue = false;
        }
    }
    void OnTriggerStay2D(Collider2D other)
    {
        Animator animator = FindObjectOfType<DialogueManager>().animator;
        if (other.gameObject.tag == "Player")
        {
            if (animator.GetBool("IsOpen") == false)
            {
                in_dialogue = false;
            }
            if (Input.inputString == "e" && animator.GetBool("IsOpen") == false)
            {
                Debug.Log("Enter dialogue");
                if (in_dialogue == false)
                {
                    FindObjectOfType<DialogueManager>().StartDialogue(dialogue);
                    in_dialogue = true;
                }
            }
            else if (Input.inputString == "e" && animator.GetBool("IsOpen") == true)
            {
                FindObjectOfType<DialogueManager>().DisplayNextSentence();
            }
            else if (Input.inputString == "q" && animator.GetBool("IsOpen") == true)
            {
                FindObjectOfType<DialogueManager>().EndDialogue();
                in_dialogue = false;
            }
        }
    }
    void OnTriggerExit2D(Collider2D other)
    {
        FindObjectOfType<DialogueManager>().EndDialogue();
        in_dialogue = false;
    }
}
