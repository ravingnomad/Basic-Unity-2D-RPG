﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroyed : MonoBehaviour {

    public Destroyable item;

    private void Update()
    {
        Animator animator = FindObjectOfType<Destroyable>().animator;
        if (item.health == 0)
        {
            animator.SetBool("isBroken", true);
        }
    }
}
